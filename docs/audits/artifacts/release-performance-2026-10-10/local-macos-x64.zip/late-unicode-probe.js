'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto'),{spawnSync}=require('child_process');
const {stats}=require(process.cwd()+'/scripts/release_performance_campaign');
const root=path.resolve('.audit-evidence/release-performance');
const source='mut text := "abcd" for i in range(16) { text = text + text } text = text + "界" mut count := 0 for i in range(100) { count = ai_count_tokens(text) } print(count)';
const script=path.join(root,'late-unicode.kujo');fs.writeFileSync(script,source);
const binaries=['kujo-baseline','kujo-candidate'].map(n=>path.join(root,n));
const timings=[[],[]],warmups=[[],[]];
for(let round=0;round<13;round++)for(let offset=0;offset<2;offset++){
 const mode=(round+offset)%2,start=process.hrtime.bigint();
 const r=spawnSync(binaries[mode],['run',script],{encoding:'utf8',timeout:60000});
 const ns=Number(process.hrtime.bigint()-start);
 if(r.error||r.status!==0||r.stdout!=='65537\n'||r.stderr!=='')throw Error('late-Unicode oracle failed: '+JSON.stringify(r));
 (round<2?warmups:timings)[mode].push(ns);
}
const result={schema:'kujo.supplemental-token-probe/v1',source,order:'(round + offset) % 2',discarded_warmups:2,samples_per_binary:11,binaries:binaries.map(p=>({name:path.basename(p),sha256:crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')})),warmups_ns:warmups,baseline_ns:timings[0],candidate_ns:timings[1],baseline_ms:stats(timings[0].map(n=>n/1e6)),candidate_ms:stats(timings[1].map(n=>n/1e6))};
fs.writeFileSync(path.join(root,'late-unicode.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({baseline_ms:result.baseline_ms.median,candidate_ms:result.candidate_ms.median}));
